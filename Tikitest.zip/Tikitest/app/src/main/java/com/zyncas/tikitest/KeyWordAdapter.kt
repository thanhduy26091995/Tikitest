package com.zyncas.tikitest

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class KeyWordAdapter(val listKeyWord: List<String>, val activity: Activity) : RecyclerView.Adapter<KeyWordAdapter.KeyWordViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KeyWordViewHolder {
        val itemView: View = activity.layoutInflater.inflate(R.layout.item_keyword, parent, false)
        return KeyWordViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return listKeyWord.size
    }

    override fun onBindViewHolder(holder: KeyWordViewHolder, position: Int) {
        val keyword = listKeyWord.get(position)
        holder.mTvKeyWord.text = keyword
    }

    class KeyWordViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mTvKeyWord: TextView = itemView.findViewById(R.id.tv_keyword)
    }
}